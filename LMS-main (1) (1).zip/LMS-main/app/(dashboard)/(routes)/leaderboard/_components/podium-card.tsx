import React from "react";

const PodiumCard = () => {
  return <div>بطاقة المنصة</div>;
};

export default PodiumCard;
